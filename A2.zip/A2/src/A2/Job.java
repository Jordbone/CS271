package A2;

import net.datastructures.SortedPriorityQueue;
import java.util.*;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Jordan Bruette
 * CS271
 * 4/9/2022
 * Work with queues and visualizing code
 * Bugs: I wasn't sure what exactly was meant by the maxWaitingTime and the timeWaiting variable, so time remaining isn't always correct and the priority number doesnt change
 */

public class Job {
    public static void main(String[] args) throws Exception {
        int priority = 0; //priority of the job
        int length = 0; //length of the job
        int timeWaiting = 0; //how long to wait
        String name = ""; //name of the specific job
        int decider = 0; //used in the reading of the text file to make sure the priority is either a negative or positive number
        SortedPriorityQueue<Integer,String> CPUsched = new SortedPriorityQueue<>();
        ArrayList<Integer> lengthofJob = new ArrayList<>(); //list of lengths of each job
        File file = new File("jobs.txt"); //open text file
            try (Scanner scan = new Scanner(file)) {
                while(scan.hasNextLine()) { //while there is another line to read
                    while(scan.hasNext()) { //while there are words to read from the specific line
                    String word = scan.next();
                    if(word.length() == 1) { //find the name of the job
                        name = word;
                        break;
                    }
                }
                if(scan.hasNextLine() == false) { //if nothing left to read, break
                    break;
                }
                String jobSpecifics = scan.nextLine(); //read the rest of the line from the text file
                if(jobSpecifics.contains("-")) { //if it contains -, the priority number is negative
                    decider = 1;
                }
                else { //otherwise its positive
                    decider = 0;
                }
                jobSpecifics = jobSpecifics.replaceAll("[^0-9]", ""); //get the numbers from each line
                if(jobSpecifics.equals("")) { //no new job this slice
                    break;
                }
                else {
                    length = Integer.parseInt(jobSpecifics.substring(0, 1)); //length of the job
                    lengthofJob.add(length); //add to array with each length of the job
                    priority = Integer.parseInt(jobSpecifics.substring(1, jobSpecifics.length())); //priority the job has
                    if(decider == 1) { //convert to negative
                        priority = 0 - priority;
                    }
                    CPUsched.insert(priority, name); //add the job to the queue
                    }
                }
            }
            catch(FileNotFoundException e) {
                e.printStackTrace();
            }
            while(!CPUsched.isEmpty()){ //while the queue isnt empty and there are jobs to fulfill
                length = lengthofJob.remove(0);
                for(int x = length-1; x >= 0; x--) {
                    System.out.println(CPUsched.min().getValue() + " (priority: " + CPUsched.min().getKey() + ", time remaining: " + x + ")");
                }
                CPUsched.removeMin();
            }
            System.out.println("Done!");
    }
}
